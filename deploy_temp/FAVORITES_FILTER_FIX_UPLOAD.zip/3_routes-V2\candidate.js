const express = require("express");

const router = express.Router();

const { verifyAuth } = require("../middleware/auth");
const { daysCountMiddleware } = require("../middleware/subsciptionDaysCount");
const candidateCtrl = require("../controllerV2/candidate");
const {
  createCandidatesCsvFile,
  hiredCandidateforClients,
  sendBulkMailToCandidates,
  getClientCandidates,
  getCandidates,
  createCandidates,
  deleteCandidate,
  candidateUpdate,
  candidateView,
  checkCandidate,
  getPublicCandidateForApply,
  changeCandidatesDataSructure,
  getallcandidates,
  BestMatchClientCandidates,
  getCandidateSelfStatistics,
  candidateJobMatching,
  getSingleCandidateDetails,
  parseResume,
  publicParseResume,
  getResumeExtractionConfigStatus,
} = candidateCtrl;

let SavedCandidate;
let toggleFavoriteCandidate;
try {
  const saved = require("../controllerV2/saved_Candidates");
  SavedCandidate = saved.SavedCandidate;
  toggleFavoriteCandidate = saved.toggleFavoriteCandidate;
} catch (e) {
  console.error("saved_Candidates load error:", e.message);
}

router.post("/candidate/create", verifyAuth, createCandidates);
router.post("/candidate/create/csv", createCandidatesCsvFile);
router.post("/candidate/check", checkCandidate);
if (typeof getPublicCandidateForApply === "function") {
  router.get("/candidate/public-apply/:id", getPublicCandidateForApply);
}
router.put("/candidate/update", verifyAuth, candidateUpdate);
router.delete("/candidate/delete/:id", verifyAuth, deleteCandidate);
router.post("/candidates", verifyAuth, getCandidates);
router.post("/candidate/view/:id", verifyAuth, candidateView);
router.post("/candidate/hired", verifyAuth, hiredCandidateforClients);
router.post("/candidate/mail", verifyAuth, sendBulkMailToCandidates);
router?.post("/clients/candidates", verifyAuth, getClientCandidates);
router?.post(
  "/clients/bestmatchcandidate",
  verifyAuth,
  BestMatchClientCandidates
);
router?.post(
  "/candidates/changedata",
  // verifyAuth,
  changeCandidatesDataSructure
);
router.post("/candidate/jobmatching", verifyAuth, candidateJobMatching);
router.get("/candidate/profile", verifyAuth, getSingleCandidateDetails);
router.get("/candidate/resume-extraction-status", verifyAuth, getResumeExtractionConfigStatus);
router.get("/candidate/public-resume-extraction-status", getResumeExtractionConfigStatus);
router.post("/candidate/parse-resume", verifyAuth, parseResume);
router.post("/candidate/parseResume", verifyAuth, parseResume);
//public Routes
router.post("/candidate/publicCreate", createCandidates);
router.post("/candidate/publicParseResume", publicParseResume);
router.post("/candidate/public-parse-resume", publicParseResume);
router.post("/candidate/savedcandidate", verifyAuth, SavedCandidate);
if (typeof toggleFavoriteCandidate === "function") {
  router.post("/candidate/toggle-favorite", verifyAuth, toggleFavoriteCandidate);
  router.post("/candidate/favorite", verifyAuth, toggleFavoriteCandidate);
}
router.get(
  "/candidate/statistics",
  verifyAuth,
  getCandidateSelfStatistics
);

module.exports = router;
